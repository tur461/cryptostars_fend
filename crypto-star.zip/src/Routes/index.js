import PublicRoutes from "./PublicRoutes/PublicRoutes";
import PrivateRoutes from "./PrivateRoutes/PrivateRoutes";

export { PublicRoutes, PrivateRoutes };
